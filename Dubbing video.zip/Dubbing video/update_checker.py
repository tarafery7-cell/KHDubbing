
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
import tkinter as tk
from tkinter import messagebox
from pathlib import Path

APP_VERSION = "1.0.0"
OWNER = "tarafery7-cell"
REPO = "KHDubbing"
ASSET_NAME = "KHDubbing-update.zip"

RELEASE_API = (
    f"https://api.github.com/repos/{OWNER}/{REPO}/releases/latest"
)

APP_DIR = Path(__file__).resolve().parent


def version_tuple(version):
    import re
    return tuple(int(x) for x in re.findall(r"\d+", version))


def get_release():
    request = urllib.request.Request(
        RELEASE_API,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "KH-Dubbing-Updater"
        }
    )

    with urllib.request.urlopen(request, timeout=15) as response:
        release = json.loads(response.read().decode("utf-8"))

    tag = release.get("tag_name", "").strip()

    if not tag:
        return None

    if version_tuple(tag) <= version_tuple(APP_VERSION):
        return None

    asset = next(
        (
            item for item in release.get("assets", [])
            if item.get("name") == ASSET_NAME
        ),
        None
    )

    if not asset:
        raise RuntimeError(
            f"GitHub Release មិនមានឯកសារ {ASSET_NAME}"
        )

    return {
        "version": tag,
        "url": asset["browser_download_url"],
        "notes": release.get("body", "")
    }


def download_and_start(release, popup, root):
    def worker():
        try:
            temp_dir = Path(tempfile.mkdtemp(prefix="khdubbing_update_"))
            zip_path = temp_dir / ASSET_NAME

            request = urllib.request.Request(
                release["url"],
                headers={"User-Agent": "KH-Dubbing-Updater"}
            )

            with urllib.request.urlopen(request, timeout=60) as response:
                with open(zip_path, "wb") as output:
                    shutil.copyfileobj(response, output)

            updater_source = APP_DIR / "updater.py"

            if not updater_source.is_file():
                raise RuntimeError(
                    "រកមិនឃើញ updater.py នៅក្នុង Folder កម្មវិធី"
                )

            # Copy updater to TEMP so it can run after app closes.
            updater_copy = temp_dir / "kh_dubbing_updater.py"
            shutil.copy2(updater_source, updater_copy)

            command = [
                sys.executable,
                str(updater_copy),
                "--pid", str(os.getpid()),
                "--zip", str(zip_path),
                "--target", str(APP_DIR),
                "--python", sys.executable
            ]

            flags = 0
            if os.name == "nt":
                flags = (
                    getattr(subprocess, "DETACHED_PROCESS", 0)
                    | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                )

            subprocess.Popen(
                command,
                cwd=str(APP_DIR),
                creationflags=flags,
                close_fds=True
            )

            def close_app():
                try:
                    popup.destroy()
                except Exception:
                    pass
                root.destroy()

            root.after(0, close_app)

        except Exception as error:
            def show_error():
                messagebox.showerror(
                    "KH Dubbing - Update Error",
                    f"មិនអាចទាញយក Update បានទេ៖\n\n{error}",
                    parent=root
                )

            root.after(0, show_error)

    threading.Thread(target=worker, daemon=True).start()


def show_update(root, release):
    popup = tk.Toplevel(root)
    popup.title("KH Dubbing - Update")
    popup.resizable(False, False)
    popup.transient(root)
    popup.grab_set()

    tk.Label(
        popup,
        text=f"មាន Version ថ្មី៖ {release['version']}",
        font=("Arial", 13, "bold"),
        padx=20,
        pady=12
    ).pack()

    tk.Label(
        popup,
        text=f"Version បច្ចុប្បន្ន៖ {APP_VERSION}",
        padx=20
    ).pack()

    notes = release["notes"].strip() or "មានការកែប្រែថ្មី។"

    tk.Label(
        popup,
        text=notes[:600],
        wraplength=380,
        justify="left",
        padx=20,
        pady=10
    ).pack()

    button_frame = tk.Frame(popup, padx=15, pady=12)
    button_frame.pack()

    download_button = tk.Button(
        button_frame,
        text="Download & Update",
        command=lambda: (
            download_button.config(
                state="disabled",
                text="Downloading..."
            ),
            download_and_start(release, popup, root)
        )
    )
    download_button.pack(side="left", padx=5)

    tk.Button(
        button_frame,
        text="Later",
        command=popup.destroy
    ).pack(side="left", padx=5)

    popup.update_idletasks()
    popup.geometry(
        f"+{root.winfo_rootx() + 50}+{root.winfo_rooty() + 50}"
    )


def check_update():
    root = tk._default_root

    if root is None:
        return

    def worker():
        try:
            release = get_release()

            if release:
                root.after(0, lambda: show_update(root, release))

        except Exception as error:
            print("GitHub Update Check Error:", error)

    threading.Thread(target=worker, daemon=True).start()
